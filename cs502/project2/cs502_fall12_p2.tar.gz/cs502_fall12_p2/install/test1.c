void foo(int i)
{
   int a;
   if (i) a = 1;
   printf("a = %d", a);
}
main()
{
   foo(0);
}

